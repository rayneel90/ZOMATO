rm(list=ls())
cat('\014')

###############################################################################
#                           Load External Libraries                           #
###############################################################################
library(caret)
library(data.table)

###############################################################################
#                     Custom Function - Train-Test Split                      #
###############################################################################

train_split=function(dat,train_fraction)
{
  train_size = round(train_fraction*nrow(dat))
  counter=0
  CIF=unique(dat$CIF)
  while(counter<train_size)
  {
    smpl = sample(CIF,1)
    if (exists('train',inherits=F))
    {
      train=rbind(train,dat[CIF==smpl])
    }else
    {
      train = dat[CIF==smpl]
    }
    counter=counter+nrow(dat[CIF==smpl])
    CIF=CIF[which(CIF!=smpl)]
  }
  return(list(train,dat[!train, on='AggrNo']))
}

dat=readRDS('data/finaldatajan17.RDS')



###############################################################################
#                          Preprocessing                                      #
###############################################################################

#########         Center n Scale all Continuous Variables        ##############

preprocessor = preProcess(dat,metod=c('center','scale'))
dat=predict(preprocessor,dat)

########                 One Hot Encoding of Factors               ############
id = dat[,AggrNo]
dat[,AggrNo:=NULL]
dat[,CIF:=as.integer(CIF)]
dat[,target:=as.integer(target)]
ohe =dummyVars("~.",data=dat,sep = "_",fullRank = T)
dat2=data.table(predict(ohe,newdata = dat))
dat=cbind(AggrNo=id,dat2)

